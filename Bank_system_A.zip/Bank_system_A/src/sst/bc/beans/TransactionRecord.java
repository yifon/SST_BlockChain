package sst.bc.beans;

public class TransactionRecord {
	
	private int recordId;
	private String txnType;
	private String fromAccount;
	private String toAccount;
	private double amount;
	public TransactionRecord(int recordId, String txnType, String fromAccount, String toAccount, double amount) {
		super();
		this.recordId = recordId;
		this.txnType = txnType;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.amount = amount;
	}
	public TransactionRecord() {
		super();
	}
	public int getRecordId() {
		return recordId;
	}
	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public String getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(String fromAccount) {
		this.fromAccount = fromAccount;
	}
	public String getToAccount() {
		return toAccount;
	}
	public void setToAccount(String toAccount) {
		this.toAccount = toAccount;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "TransactionRecord [recordId=" + recordId + ", txnType=" + txnType + ", fromAccount=" + fromAccount
				+ ", toAccount=" + toAccount + ", amount=" + amount + "]";
	}
	
	

}
