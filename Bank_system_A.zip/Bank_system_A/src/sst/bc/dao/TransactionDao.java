package sst.bc.dao;

public class TransactionDao {

}
