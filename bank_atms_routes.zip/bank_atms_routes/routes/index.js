/*
 * GET home page.
 */
var accounts = require('./accounts');
var terminal = require('./terminal');
var account = new accounts();
//need change to the real server once in prod
var BankA001_url ='';
var BankA002_url ='http://119.23.28.88:6100/';
var BankB001_url ='http://120.79.43.12:6200/';
var BankB002_url ='';
var BankC001_url ='';
var BankC002_url ='';
exports.index = function(req, res) {
	res.render('index', {
		title : 'Select terminal',
		message : 'welcome to SST block chain system',
		
	});
};


exports.selectTerminalDone = function(req, res) {
	
	this.terminal = {atm_id:req.query.terminalId};
	req.session.terminal=this.terminal;
	//req.session.terminalId=req.query.terminalId;
	console.log(req.session.terminal.atm_id);
	switch (req.session.terminal.atm_id) {
	case 'BankA001':
		req.session.atmurl = BankA001_url;
		break;
	case 'BankA002':
		req.session.atmurl = BankA002_url;
		break;
	case 'BankB001':
		req.session.atmurl = BankB001_url;
		break;
	case 'BankB002':
		req.session.atmurl = BankB002_url;
		break;
	case 'BankC001':
		req.session.atmurl = BankC001_url;
		break;
	case 'BankC002':
		req.session.atmurl = BankC002_url;
		break;
	default:
		req.session.atmurl = BankA002_url;
	}
	console.log('selectTerminalDone  success');
	console.log(req.session.atmurl);
	res.render('insert_card', {
		title: 'Insert Card', 
	   // bankName: req.session.terminal.bank_name, 
		terminalId:req.session.terminal.atm_id 
		});
	
};
exports.insertCardDone = function(req, res) {
	
		console.log('insertCardDone  success');
		
		this.account={card_number: req.query.cardNumber,issue_bank: req.query.issueBank};
		
		req.session.Account=this.account;
		console.log(this.account);
		//return account;
		res.render('enter_pin', {
			title: 'Enter pin', 
		//    bankName: req.session.terminal.bank_name, 
			//terminalId:req.session.terminal.atm_id,
			cardNumber:req.session.Account.card_number
			});
		
	
};
exports.enterPinDone = function(req, res) {
	
	console.log('enterPinDone  success');
	
	this.account.pin = req.query.pin;
	
	req.session.Account=this.account;
	console.log(this.account);
	//return account;
	res.render('transaction_select', {
		title: 'transaction_select', 
	 //   bankName: req.session.terminal.bank_name, 
		//terminalId:req.session.terminal.atm_id,
		cardNumber:req.session.Account.card_number
		});
};
exports.transactionSelectDone = function(req, res) {
	
	console.log('transactionSelectDone  success');
	
	this.account.transaction_type = req.query.transaction_type;
	
	req.session.Account=this.account;
	console.log(this.account);
	//return account;
	


		switch (this.account.transaction_type) {
	case 'cwd':
		res.render('enter_amount', {
			title: 'Enter Amount', 
	//	    bankName: req.session.terminal.bank_name, 
		//	terminalId:req.session.terminal.atm_id,
			cardNumber:req.session.Account.card_number
			});
		break;
	case 'inq':
		res.redirect(req.session.atmurl+'inq?card_number='+this.account.card_number+'&pin='+this.account.pin+'&transaction_type='+this.account.transaction_type+'&issue_bank='+this.account.issue_bank);
		break;
	case 'pin':

		break;
	case 'cdp':
		   res.render('insert_cash', {
			title: 'Insert Cash', 
		//    bankName: req.session.terminal.bank_name, 
		//	terminalId:req.session.terminal.atm_id,
			cardNumber:req.session.Account.card_number
			});

		break;
	default:
		res.render('transaction_select', {
			title: 'transaction_select', 
		 //   bankName: req.session.terminal.bank_name, 
			//terminalId:req.session.terminal.atm_id,
			cardNumber:req.session.Account.card_number
			});
	}
	
};
exports.enterAmountDone = function(req, res) {
	
	console.log('enterAmountDone  success');
	
	this.account.amount = req.query.amount;
	
	req.session.Account=this.account;
	console.log(this.account);
	//return account;
	res.redirect(req.session.atmurl+'cwd?card_number='+
			this.account.card_number+
			'&pin='+this.account.pin+
			'&transaction_type='+req.session.Account.transaction_type+
			'&issue_bank='+req.session.Account.issue_bank+
			'&amount='+req.session.Account.amount);
};
exports.insertCashDone = function(req, res) {
	
console.log('insertCashDone  success');
	
	this.account.amount = req.query.amount;
	
	req.session.Account=this.account;
	console.log(this.account);
	//return account;
	res.redirect(req.session.atmurl+'cdp?card_number='+
			this.account.card_number+
			'&pin='+this.account.pin+
			'&transaction_type='+req.session.Account.transaction_type+
			'&issue_bank='+req.session.Account.issue_bank+
			'&amount='+req.session.Account.amount);
};
exports.inqResult = function(req, res) {

	console.log('inqResult  success');

	//this.account.status = req.query.status;
	//this.account.balance = req.query.balance;
	this.account={
			    card_number: req.query.cardNumber,
			    balance: req.query.balance,
			    pin: req.query.pin,
			    amount: req.query.amount,
			    transaction_type: req.query.transactionType,
			    status: req.query.status};
	//req.session.Account = this.account;
	console.log(this.account);
	// return account;
	if (req.query.status==="true") {

		res.render('inq_result', {
			title : 'inq_result',
		//	bankName : req.query.bankName,
			terminalId : req.query.atmId,
			cardNumber : this.account.card_number,
			status :  this.account.status,
			balance : this.account.balance
		});
		req.session.Account = null;
		this.account=null;
		
	} else {
		res.render('failed', {
			title : 'inq_result',
		//	bankName : req.query.bankName,
			terminalId : req.query.atmId,
			cardNumber : this.account.card_number,
			status :  this.account.status,
			balance : this.account.balance
		});
		req.session.Account = null;
		this.account=null;
	}
};
exports.cdpResult = function(req, res) {

	console.log('cdpResult  success');

	//this.account.status = req.query.status;
	//this.account.balance = req.query.balance;
	this.account={
			    card_number: req.query.cardNumber,
			    balance: req.query.balance,
			    pin: req.query.pin,
			    amount: req.query.amount,
			    transaction_type: req.query.transactionType,
			    status: req.query.status};
	//req.session.Account = this.account;
	console.log(this.account);
	// return account;
	if (req.query.status==="true") {

		res.render('cdp_result', {
			title : 'cdpresult',
		//	bankName : req.query.bankName,
			terminalId : req.query.atmId,
			cardNumber : this.account.card_number,
			status :  this.account.status,
			balance : this.account.balance,
			amount:this.account.amount,
		});
		req.session.Account = null;
		this.account=null;
		
	} else {
		res.render('failed', {
			title : 'cdrResult',
		//	bankName : req.query.bankName,
			terminalId : req.query.atmId,
			cardNumber : this.account.card_number,
			status :  this.account.status,
			balance : this.account.balance,
			amount: this.account.amount
		});
		req.session.Account = null;
		this.account=null;
	}
};
exports.cwdResult = function(req, res) {

	console.log('cwdResult  success');

	//this.account.status = req.query.status;
	//this.account.balance = req.query.balance;
	this.account={
			    card_number: req.query.cardNumber,
			    balance: req.query.balance,
			    pin: req.query.pin,
			    amount: req.query.amount,
			    transaction_type: req.query.transactionType,
			    status: req.query.status};
	//req.session.Account = this.account;
	console.log(this.account);
	// return account;
	if (req.query.status==="true") {

		res.render('cwd_result', {
			title : 'cwdresult',
			//bankName : req.query.bankName,
			terminalId : req.query.atmId,
			cardNumber : this.account.card_number,
			status :  this.account.status,
			balance : this.account.balance,
			amount:this.account.amount
		});
		req.session.Account = null;
		this.account=null;
		
	} else {
		res.render('failed', {
			title : 'cwdresult',
		//	bankName : req.query.bankName,
			terminalId : req.query.atmId,
			cardNumber : this.account.card_number,
			status :  this.account.status,
			balance : this.account.balance,
			amount:this.account.amount
		});
		req.session.Account = null;
		this.account=null;
	}
};




