/**
 * http://usejsdoc.org/
 */

var http = require('http');
var Web3 = require('web3');
var fs = require('fs');
var txn_request_hsbc = require('./txn_request_hsbc');

//constant abi 
var constant_abi = [{"constant":false,"inputs":[{"name":"x","type":"uint256"}],"name":"set","outputs":[],"payable":false,"type":"function"},{"constant":true,"inputs":[],"name":"get","outputs":[{"name":"retVal","type":"uint256"}],"payable":false,"type":"function"},{"constant":false,"inputs":[{"name":"a","type":"uint256"}],"name":"multiply","outputs":[{"name":"d","type":"uint256"}],"payable":false,"type":"function"},{"anonymous":false,"inputs":[{"indexed":false,"name":"_from","type":"address"}],"name":"TestEvent","type":"event"}];

//add
var constant_add = '0xE1F977517D6D329eaa4C04dF1d543eF6A2184a4C'; //test address
var card_issue_bank = "0xed9d02e382b34818e88b88a309c7fe71e65f419d"; //hase card//TODO 
var this_bank_address = '0x353c1c4aa32e54ae8278403d27e287c4b43ffdf1 ';  //play as node2;  for incoming address
var this_atm_address = '0xb6d55e2e50e8cfbaf87ad6f0e29fbf663104a590'; //play as node1
var nodeContract;
var createhashcode = require('./createhashcode');
var trxHash ;
//var web3;
function contractNodetest() {

	
}
contractNodetest.cwdrequest = function(vars, authorisedCallback) {
	console.log(vars.cardNumber);
	console.log(vars.trxHash);
	console.log(vars.pin);
	console.log(vars.amount);
	var web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'));
	nodeContract = web3.eth.contract(constant_abi).at(constant_add);
    createhashcode.gethashCode(Date.now().toString(),function(str){
		
		trxHash = str;
	});
	//startWithdraw(address _fromATM, string trxHash,  address _issueBank, string _account, string _pwd, int _amount)
//	nodeContract.startWithdraw(
//			this_atm_address, trxHash,
//			card_issue_bank, vars.cardNumber, vars.pin,
//			vars.amount, {
//				from : web3.eth.coinbase,
//				gas : 0x47b760
//			});
    console.log(web3.eth.accounts);
    console.log( nodeContract.get());
   
//	var event = nodeContract.WithdrawalAuthorisation();
//	event.watch(function(err, res) {
//		if (!err) {
//			console.log("WithdrawalAuthorisation arrived at contract："+ res.address);
//			console.log(res.args);
//			if(vars.trxHash===res.trxHash){
//			  authorisedCallback(res.args);
//			}
//			
//
//		} else {
//			console.log(err);
//		}

	//});
};

contractNodetest.cwdlistener = function() {
	//startWithdraw(address _fromATM, string trxHash,  address _issueBank, string _account, string _pwd, int _amount)
	//startWithdraw(address _fromATM, string trxHash,  address _issueBank, string _account, string _pwd, int _amount)
	var web3 = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'));
	nodeContract = web3.eth.contract(constant_abi).at(constant_add);
	
	var event = nodeContract.TestEvent();
	console.log(web3.eth.accounts);
	   event.watch(function(err,res){
           if(!err){
             console.log("WithdrawalRequest arrived at contract："+res.address);
             console.log(res.args);
             //to call atmp 
             //authorised: function(_fromAtm, _issueBank, trxHash, status, _amount,int fee)
             //authorised();//to simulate atmp response
            var cwd = {cardNumber: res.args._account, pin: res.args._pwd,amount:res.args._amount};
         	txn_request_hsbc.cwdrequest(cwd, function(err, statuss){
        		if (err) {
        			console.log(err);
        		}else{
        			var status = statuss[0];
        			var balance = statuss[1];
        			var responseCode = "2000";  // accept 1000
        			if(status==="true"){
        				responseCode = "1000";
        			}
        			setTimeout(function(){
        				//authorised: function(_fromAtm, _issueBank, trxHash, status, _amount,int fee)
        	          var hash=nodeContract.startAuthorise(res.args._fromAtm,this_atm_address,res.args.trxHash,responseCode,res.args._amount,2, {from: web3.eth.coinbase, gas: 0x47b760});
        	               console.log("start auth:"+hash);
        	             },1000);
        		}
        		
        	});
             //nodeContract.startAuthorise(address _fromAtm, address _issueBank, string trxHash, int status, int _amount,int fee);
           //  nodeContract.startAuthorise(address _fromAtm, address _issueBank, string trxHash, int status, int _amount,int fee) 
           }else{
             console.log(err);
           }
           
         });
};

//not in use

module.exports=contractNodetest;