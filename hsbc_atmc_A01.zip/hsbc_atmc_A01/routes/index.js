/*
 * GET home page.
 */
var accounts = require('./accounts');
var txn_request_bank_a = require('./txn_request_bank_a');
//var contractNodetest = require('./contractNodetest');
var txn_request_out_going = require('./contractNode');
//need change to the real server once in prod
var routers_url = 'http://39.108.142.194:3000/';
//var terminal = require('./terminal');
var account = new accounts();
//var contract = new contractNodetest();
var bank_b = 'bank_b';
var this_bank = 'bank_a';
var bank_c = 'bank_c';
var fs = require('fs');
exports.index = function(req, res) {
	res.render('index', {
		title : 'express',
		//message : 'welcome to SST block chain system',
		
	});
};

exports.cwdtxn = function(req, res) {
	
	console.log('cwdtxn');
    this.account={card_number:req.query.card_number,pin:req.query.pin,transaction_type:req.query.transaction_type,issue_bank: req.query.issue_bank,amount:req.query.amount};
	console.log(this.account);
	var cwd = {cardNumber: this.account.card_number, pin: this.account.pin,amount:this.account.amount};
	if(this.account.issue_bank===this_bank){
		txn_request_bank_a.cwdrequest(cwd, function(err, statuss){
		if (err) {
			console.log(err);
		}else{
			this.account.status = statuss[0];
			this.account.balance = statuss[1];
			res.redirect(routers_url+'cwd_result?cardNumber='+this.account.card_number+'&pin='+this.account.pin+'&transactionType='+this.account.transaction_type+'&bankName=HSBC&atmId=A001'+'&status='+this.account.status+'&balance='+this.account.balance+'&amount='+this.account.amount);
		}
		
	});
	}else{
		console.log(this.account);	
		console.log('out going handling');
		txn_request_out_going.cwdrequest(cwd, function(trxHash){
		
			function  myfunc(Interval){
				fs.exists(trxHash+".txt", function(exists) {  
				    console.log(trxHash+".txt :exists= "+exists); 
				    if(exists){
				    	stopInterval();
				   	       fs.readFile(trxHash+".txt", 'utf-8',function(err,data){
						    console.log(data);
						    var statuss = data.split('|');
						    console.log(statuss);
							console.log(statuss[0]);
							console.log(statuss[1]);
							console.log('routers_url='+routers_url);
							this.account.status = statuss[0];
							this.account.balance = statuss[1];
							res.redirect(routers_url+'cwd_result?cardNumber='+this.account.card_number+'&pin='+this.account.pin+'&transactionType='+this.account.transaction_type+'&bankName=HSBC&atmId=A001'+'&status='+this.account.status+'&balance='+this.account.balance+'&amount='+this.account.amount);
					 });
				    }
				});
			}
			var myInterval=setInterval(myfunc,1000,"Interval");
			function  stopInterval(){
			    clearTimeout(myInterval);
			 //myInterval.unref();
			}
			setTimeout(stopInterval,5000);
			
		});
	}
	
};
exports.inqtxn = function(req, res) {
	    console.log('inqtxn');
	    this.account={card_number:req.query.card_number,pin:req.query.pin,transaction_type:req.query.transaction_type,issue_bank: req.query.issue_bank};
		console.log(this.account);
		var inq = {cardNumber: this.account.card_number, pin: this.account.pin};
		if(this.account.issue_bank===this_bank){
			txn_request_bank_a.inqrequest(inq,function(err,statuss){
			if (err) {
				console.log(err);
			}else{
			this.account.status = statuss[0];
			this.account.balance = statuss[1];
			res.redirect(routers_url+'inq_result?cardNumber='+this.account.card_number+'&pin='+this.account.pin+'&transactionType='+this.account.transaction_type+'&bankName=HSBC&atmId=A001'+'&status='+this.account.status+'&balance='+this.account.balance);
			}});
		}else{
			
			//console.log(this.account);
			console.log(txn_request_out_going);
			txn_request_out_going.inqrequest(inq, function(statuss){
				
					console.log(statuss);
					this.account.status = statuss[0];
					this.account.balance = statuss[1];
					res.redirect(routers_url+'inq_result?cardNumber='+this.account.card_number+'&pin='+this.account.pin+'&transactionType='+this.account.transaction_type+'&bankName=HSBC&atmId=A001'+'&status='+this.account.status+'&balance='+this.account.balance);
				
			});
			
			
		}
	
};
exports.pintxn = function(req, res) {
	
	console.log('enterPinDone  success');
	
	this.account.pin = req.query.pin;
	
	req.session.Account=this.account;
	console.log(this.account);
	//return account;
	res.render('transaction_select', {
		title: 'transaction_select', 
	    bankName: req.session.terminal.bank_name, 
		terminalId:req.session.terminal.atm_id,
		cardNumber:req.session.Account.card_number
		});
};
exports.cdptxn = function(req, res) {
	
	 console.log('cdptxn');
	    this.account={card_number:req.query.card_number,pin:req.query.pin,transaction_type:req.query.transaction_type,issue_bank: req.query.issue_bank,amount:req.query.amount};
		console.log(this.account);
		var cdp = {cardNumber: this.account.card_number, pin: this.account.pin,amount:this.account.amount};
		if(this.account.issue_bank===this_bank){
			txn_request_bank_a.cdprequest(cdp, function(err, statuss){
			if (err) {
				console.log(err);
			}else{
				this.account.status = statuss[0];
				this.account.balance = statuss[1];
				res.redirect(routers_url+'cdp_result?cardNumber='+this.account.card_number+'&pin='+this.account.pin+'&transactionType='+this.account.transaction_type+'&bankName=HSBC&atmId=A001'+'&status='+this.account.status+'&balance='+this.account.balance+'&amount='+this.account.amount);
			}
		});
		}else{
			
			console.log(this.account);
			console.log('out going handling');
			txn_request_out_going.cdprequest(cdp, function(statuss){
					console.log(statuss);
					this.account.status = statuss[0];
					this.account.balance = statuss[1];
					res.redirect(routers_url+'cdp_result?cardNumber='+this.account.card_number+'&pin='+this.account.pin+'&transactionType='+this.account.transaction_type+'&bankName=HSBC&atmId=A001'+'&status='+this.account.status+'&balance='+this.account.balance+'&amount='+this.account.amount);
				
			});
			
		}
	
};




