/**
 *  transaction modules
 *  
 *  
 */

/**
 * @returns
 */
function status() {
    
	var restult ;
	var balance;
	
	this.setRestult = function(_restult) {

		restult = _restult;
	};
	
	this.setBalance = function(_balance) {

		balance = _balance;
	};
	


}
module.exports = status;