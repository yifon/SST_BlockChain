/**
 * http://usejsdoc.org/
 */
//var contractNodetest = require('./contractNodetest');

//contractNodetest.inqrequest("sfhshfs", function(value,vars){
//	console.log('333333');
//	console.log(vars);
//	console.log(value);
//	
//});
var contractNode = require('./contractNode');
var cwd = {cardNumber: '123456', pin: 12234,amount:100};
contractNode.cwdrequest(cwd, function(statuss) {
	console.log(statuss);
});

contractNode.cwdlistener();
