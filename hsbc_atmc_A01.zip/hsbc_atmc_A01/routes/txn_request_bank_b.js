/**
 * http://usejsdoc.org/
 */

var soap = require('soap');
//var url = 'http://119.23.12.79:8080/Bank_system_hsbc/services/GetBankAccountInfoImp?wsdl';
var url = 'http://119.23.12.79:8080/Bank_system_B/services/GetBankAccountInfoImp?wsdl';
function txn_request_bank_b(){
	
}

txn_request_bank_b.cwdrequest = function (vars,callback){
	soap.createClient(url, function(err, client) {		
	    client.cashWithdrawal(vars, function(err, result) {
			if (err) {
				console.log(err);
			} else {
				console.log(result);
				var statuss = result.cashWithdrawalReturn.split('|');
				callback(err,statuss);
				
			}
		});
	});
};

txn_request_bank_b.inqrequest = function (vars,callback){
	soap.createClient(url, function(err, client) {		
	    client.getAccountBalance(vars, function(err, result) {
			if (err) {
				console.log(err);
				callback(err,"");
			} else {
				console.log(result);
				var statuss = result.getAccountBalanceReturn.split('|');
				callback(err,statuss);
				
			}
		});
	});
};
txn_request_bank_b.cdprequest = function (vars,callback){
	soap.createClient(url, function(err, client) {		
	    client.cashDeposit(vars, function(err, result) {
			if (err) {
				console.log(err);
			} else {
				console.log(result);
				var statuss = result.cashDepositReturn.split('|');
				callback(err,statuss);
				
			}
		});
	});
};

module.exports=txn_request_bank_b;
